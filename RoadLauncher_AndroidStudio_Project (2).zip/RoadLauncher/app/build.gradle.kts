plugins { id("com.android.application") }

android {
    namespace = "ru.roadlauncher"
    compileSdk = 36

    defaultConfig {
        applicationId = "ru.roadlauncher"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1"
    }
}
